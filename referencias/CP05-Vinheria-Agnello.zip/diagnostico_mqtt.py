"""Teste MQTT v3.1.1 sem bibliotecas externas para o broker do CP05.

Uso: python diagnostico_mqtt.py 3.135.234.101
Publica apenas em um topico temporario do grupo; nao altera o FIWARE.
"""

import socket
import sys
import time
import uuid


def remaining_length(value):
    encoded = bytearray()
    while True:
        digit = value % 128
        value //= 128
        encoded.append(digit | (0x80 if value else 0))
        if not value:
            return bytes(encoded)


def field(value):
    data = value.encode("utf-8")
    return len(data).to_bytes(2, "big") + data


def packet(kind, body):
    return bytes([kind]) + remaining_length(len(body)) + body


def read_exact(sock, count):
    data = bytearray()
    while len(data) < count:
        chunk = sock.recv(count - len(data))
        if not chunk:
            raise ConnectionError("Broker encerrou a conexao")
        data.extend(chunk)
    return bytes(data)


def read_packet(sock):
    kind = read_exact(sock, 1)[0]
    size = 0
    multiplier = 1
    while True:
        digit = read_exact(sock, 1)[0]
        size += (digit & 127) * multiplier
        if not digit & 128:
            break
        multiplier *= 128
    return kind, read_exact(sock, size)


def main(host):
    client_id = "cp05-diagnostico-" + uuid.uuid4().hex[:10]
    topic = "vinheria571746/diagnostico/" + client_id
    message = "teste-" + str(int(time.time()))
    with socket.create_connection((host, 1883), timeout=8) as sock:
        sock.settimeout(8)
        connect = field("MQTT") + bytes([4, 2, 0, 30]) + field(client_id)
        sock.sendall(packet(0x10, connect))
        kind, body = read_packet(sock)
        if kind != 0x20 or body != b"\x00\x00":
            raise RuntimeError(f"CONNACK inesperado: {kind:#x} {body.hex()}")
        print(f"CONNECT: aceito em {host}:1883 (MQTT v3.1.1)")

        sock.sendall(packet(0x82, b"\x00\x01" + field(topic) + b"\x00"))
        kind, body = read_packet(sock)
        if kind != 0x90 or body[:2] != b"\x00\x01" or body[2:] != b"\x00":
            raise RuntimeError(f"SUBACK inesperado: {kind:#x} {body.hex()}")
        print(f"SUBSCRIBE: aceito em {topic}")

        sock.sendall(packet(0x30, field(topic) + message.encode()))
        print(f"PUBLISH: {message}")
        while True:
            kind, body = read_packet(sock)
            if kind >> 4 != 3:
                continue
            topic_length = int.from_bytes(body[:2], "big")
            received_topic = body[2 : 2 + topic_length].decode()
            received_message = body[2 + topic_length :].decode()
            if received_topic == topic and received_message == message:
                print("RECEIVE: mensagem recebida no mesmo topico. Broker OK.")
                break
        sock.sendall(b"\xe0\x00")


def publish_diagnostic(host, topic, message):
    if not topic.startswith("vinheria571746/diagnostico/"):
        raise ValueError("Use apenas um topico de diagnostico do grupo")
    client_id = "cp05-envio-" + uuid.uuid4().hex[:10]
    with socket.create_connection((host, 1883), timeout=8) as sock:
        sock.settimeout(8)
        connect = field("MQTT") + bytes([4, 2, 0, 30]) + field(client_id)
        sock.sendall(packet(0x10, connect))
        kind, body = read_packet(sock)
        if kind != 0x20 or body != b"\x00\x00":
            raise RuntimeError(f"CONNACK inesperado: {kind:#x} {body.hex()}")
        sock.sendall(packet(0x30, field(topic) + message.encode()))
        print(f"Mensagem enviada para {topic}: {message}")
        sock.sendall(b"\xe0\x00")


if __name__ == "__main__":
    if len(sys.argv) == 2:
        main(sys.argv[1])
    elif len(sys.argv) == 4:
        publish_diagnostic(sys.argv[1], sys.argv[2], sys.argv[3])
    else:
        raise SystemExit(
            "Uso: python diagnostico_mqtt.py IP_DO_PROFESSOR "
            "[TOPICO_DIAGNOSTICO MENSAGEM]"
        )
