# Execute somente se for necessario recriar o cadastro no servidor da turma.
# Exemplo: .\provisionar-fiware.ps1 -Server 'IP_FORNECIDO_PELO_PROFESSOR'
param(
  [Parameter(Mandatory = $true)]
  [string]$Server
)

$ErrorActionPreference = 'Stop'
$service = 'vinheria571746'
$apiKey = 'cp05vinheria571746'
$deviceId = 'esp32_571746'
$entityId = 'urn:ngsi-ld:Device:vinheria-571746'
$headers = @{ 'Fiware-Service' = $service; 'Fiware-ServicePath' = '/' }
$iotAgent = "http://${Server}:4041"
$orion = "http://${Server}:1026"

$group = Invoke-RestMethod -Uri "${iotAgent}/iot/services?apikey=${apiKey}&resource=%2Fiot%2Fd" -Headers $headers
if ($group.count -eq 0) {
  $body = @{ services = @(@{
    apikey = $apiKey
    cbroker = 'http://orion:1026'
    entity_type = 'Device'
    resource = '/iot/d'
  }) } | ConvertTo-Json -Depth 8
  Invoke-RestMethod -Method Post -Uri "${iotAgent}/iot/services" -Headers $headers -ContentType 'application/json' -Body $body | Out-Null
  Write-Host 'Grupo de servico criado.'
} else {
  Write-Host 'Grupo de servico ja existe.'
}

$deviceExists = $true
try {
  Invoke-RestMethod -Uri "${iotAgent}/iot/devices/${deviceId}" -Headers $headers | Out-Null
} catch {
  if ([int]$_.Exception.Response.StatusCode -ne 404) { throw }
  $deviceExists = $false
}
if (-not $deviceExists) {
  $body = @{ devices = @(@{
    device_id = $deviceId
    entity_name = $entityId
    entity_type = 'Device'
    apikey = $apiKey
    protocol = 'PDI-IoTA-UltraLight'
    transport = 'MQTT'
    attributes = @(
      @{ object_id='t'; name='temperature'; type='Number' },
      @{ object_id='h'; name='relativeHumidity'; type='Number' },
      @{ object_id='l'; name='illuminance'; type='Number' },
      @{ object_id='ts'; name='dateObserved'; type='DateTime' }
    )
  }) } | ConvertTo-Json -Depth 8
  Invoke-RestMethod -Method Post -Uri "${iotAgent}/iot/devices" -Headers $headers -ContentType 'application/json' -Body $body | Out-Null
  Write-Host 'Dispositivo criado.'
} else {
  Write-Host 'Dispositivo ja existe.'
}

# Campos do Smart Data Model Device: controlledProperty e obrigatorio.
$encodedEntityId = [uri]::EscapeDataString($entityId)
$entityUri = "${orion}/v2/entities/${encodedEntityId}"
$entity = $null
try {
  $entity = Invoke-RestMethod -Uri $entityUri -Headers $headers
} catch {
  if (-not $_.Exception.Response -or [int]$_.Exception.Response.StatusCode -ne 404) { throw }
  Write-Warning 'Dispositivo cadastrado, mas entidade ainda nao existe no Orion. Inicie a simulacao, aguarde uma leitura MQTT e execute este script novamente para acrescentar os campos do Smart Data Model.'
}
if ($entity) {
  $modelAttributes = @{}
  if (-not $entity.PSObject.Properties['controlledProperty']) {
    $modelAttributes['controlledProperty'] = @{
      type = 'StructuredValue'
      value = @('temperature', 'relativeHumidity', 'illuminance')
    }
  }
  if (-not $entity.PSObject.Properties['deviceCategory']) {
    $modelAttributes['deviceCategory'] = @{
      type = 'StructuredValue'
      value = @('sensor')
    }
  }
  if ($modelAttributes.Count -gt 0) {
    $body = $modelAttributes | ConvertTo-Json -Depth 8
    Invoke-RestMethod -Method Post -Uri "${entityUri}/attrs" -Headers $headers -ContentType 'application/json' -Body $body | Out-Null
    Write-Host 'Campos Smart Data Model Device acrescentados.'
  } else {
    Write-Host 'Campos Smart Data Model Device ja existem.'
  }
} else {
  Write-Host 'Campos Smart Data Model Device pendentes ate a primeira leitura.'
}

$subscriptions = @(Invoke-RestMethod -Uri "${orion}/v2/subscriptions" -Headers $headers)
$existing = $subscriptions | Where-Object { $_.description -eq 'CP05 Vinheria 571746 historical readings' }
if (-not $existing) {
  $body = @{
    description = 'CP05 Vinheria 571746 historical readings'
    subject = @{
      entities = @(@{ id=$entityId; type='Device' })
      condition = @{ attrs=@('temperature','relativeHumidity','illuminance','dateObserved') }
    }
    notification = @{
      http = @{ url='http://sth-comet:8666/notify' }
      attrs = @('temperature','relativeHumidity','illuminance','dateObserved')
      attrsFormat = 'legacy'
    }
  } | ConvertTo-Json -Depth 10
  Invoke-RestMethod -Method Post -Uri "${orion}/v2/subscriptions" -Headers $headers -ContentType 'application/json' -Body $body | Out-Null
  Write-Host 'Assinatura historica criada.'
} else {
  Write-Host 'Assinatura historica ja existe.'
}

Write-Host 'Provisionamento verificado.'
