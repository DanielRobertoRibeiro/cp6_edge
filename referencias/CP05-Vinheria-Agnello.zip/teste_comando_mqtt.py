"""Publica um comando e aguarda a resposta do ESP32 via MQTT v3.1.1.

Uso: python teste_comando_mqtt.py 3.135.234.101 STATUS
"""

import socket
import sys
import uuid

from diagnostico_mqtt import field, packet, read_packet

COMMAND_TOPIC = "vinheria571746/esp32_571746/comando"
RESPONSE_TOPIC = "vinheria571746/esp32_571746/retorno"


def main(host, command, compat=False):
    if command not in {"ON", "OFF", "STATUS"}:
        raise SystemExit("Comando permitido: ON, OFF ou STATUS")
    client_id = "cp05-teste-comando-" + uuid.uuid4().hex[:10]
    with socket.create_connection((host, 1883), timeout=8) as sock:
        sock.settimeout(8)
        connect = field("MQTT") + bytes([4, 2, 0, 30]) + field(client_id)
        sock.sendall(packet(0x10, connect))
        kind, body = read_packet(sock)
        if kind != 0x20 or body != b"\x00\x00":
            raise RuntimeError(f"CONNACK inesperado: {kind:#x} {body.hex()}")

        sock.sendall(packet(0x82, b"\x00\x01" + field(RESPONSE_TOPIC) + b"\x00"))
        kind, body = read_packet(sock)
        if kind != 0x90 or body[:2] != b"\x00\x01" or body[2:] != b"\x00":
            raise RuntimeError(f"SUBACK inesperado: {kind:#x} {body.hex()}")

        topic = COMMAND_TOPIC + (":" if compat else "")
        sock.sendall(packet(0x30, field(topic) + command.encode()))
        print(f"Enviado: {command} -> {topic}")
        while True:
            kind, body = read_packet(sock)
            if kind >> 4 != 3:
                continue
            topic_length = int.from_bytes(body[:2], "big")
            topic = body[2 : 2 + topic_length].decode()
            message = body[2 + topic_length :].decode()
            if topic == RESPONSE_TOPIC:
                print(f"Recebido: {message} <- {topic}")
                break
        sock.sendall(b"\xe0\x00")


if __name__ == "__main__":
    if len(sys.argv) not in (3, 4) or (len(sys.argv) == 4 and sys.argv[3] != "--compat"):
        raise SystemExit("Uso: python teste_comando_mqtt.py IP ON|OFF|STATUS [--compat]")
    main(sys.argv[1], sys.argv[2].upper(), len(sys.argv) == 4)
