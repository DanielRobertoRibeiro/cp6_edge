#include <WiFi.h>
#include <PubSubClient.h>
#include <DHTesp.h>
#include <time.h>
#include <math.h>

// Rede virtual oferecida pelo Wokwi.
const char* WIFI_SSID = "Wokwi-GUEST";
const char* WIFI_PASSWORD = "";

// Servidor de IoT compartilhado pelo professor.
const char* MQTT_HOST = "3.135.234.101";
const uint16_t MQTT_PORT = 1883;
const char* MQTT_CLIENT_ID = "vinheria-esp32-571746";
const char* TELEMETRY_TOPIC = "/ul/cp05vinheria571746/esp32_571746/attrs";
const char* COMMAND_TOPIC = "vinheria571746/esp32_571746/comando";
// O MyMQTT desta demonstracao salvou o topico com ':' final; aceitamos ambos.
const char* COMMAND_TOPIC_COMPAT = "vinheria571746/esp32_571746/comando:";
const char* RESPONSE_TOPIC = "vinheria571746/esp32_571746/retorno";

const int DHT_PIN = 15;
const int LDR_PIN = 34; // ADC1 funciona mesmo com WiFi ativo.
const int LED_PIN = 2;
const unsigned long PUBLISH_INTERVAL_MS = 5000;

DHTesp dht;
WiFiClient wifiClient;
PubSubClient mqtt(wifiClient);
unsigned long lastPublish = 0;
unsigned long lastWifiAttempt = 0;
unsigned long lastMqttAttempt = 0;
bool ledOn = false;
bool clockConfigured = false;

String utcTimestamp() {
  struct tm now;
  if (!getLocalTime(&now, 1000) || now.tm_year + 1900 < 2025) {
    return "";
  }
  char result[25];
  strftime(result, sizeof(result), "%Y-%m-%dT%H:%M:%SZ", &now);
  return String(result);
}

float readLux() {
  int raw = analogRead(LDR_PIN);
  float voltage = raw / 4095.0f * 3.3f;
  if (voltage <= 0.001f) return 100000.0f;
  if (voltage >= 3.299f) return 0.0f;

  // LDR padrão do Wokwi: resistor fixo 10 kΩ, RL10=50 kΩ e gamma=0,7.
  float resistance = 10000.0f * voltage / (3.3f - voltage);
  float lux = powf(50000.0f * powf(10.0f, 0.7f) / resistance, 1.0f / 0.7f);
  return isfinite(lux) ? lux : 100000.0f;
}

void publishStatus(const String& message) {
  String response = message + " | LED=" + (ledOn ? "ON" : "OFF");
  mqtt.publish(RESPONSE_TOPIC, response.c_str());
  Serial.println("Resposta MQTT: " + response);
}

void onMessage(char* topic, byte* payload, unsigned int length) {
  String command;
  for (unsigned int i = 0; i < length; i++) command += (char)payload[i];
  command.trim();
  command.toUpperCase();
  Serial.println("Comando MQTT em " + String(topic) + ": " + command);

  if (command == "ON") {
    ledOn = true;
    digitalWrite(LED_PIN, HIGH);
    publishStatus("Comando ON recebido");
  } else if (command == "OFF") {
    ledOn = false;
    digitalWrite(LED_PIN, LOW);
    publishStatus("Comando OFF recebido");
  } else if (command == "STATUS") {
    publishStatus("ESP32 ativo");
  } else {
    publishStatus("Use ON, OFF ou STATUS");
  }
}

void ensureWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;
  if (lastWifiAttempt && millis() - lastWifiAttempt < 10000) return;
  lastWifiAttempt = millis();
  Serial.println("Tentando conectar ao WiFi...");
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD, 6);
}

void ensureMqtt() {
  if (WiFi.status() != WL_CONNECTED || mqtt.connected()) return;
  if (lastMqttAttempt && millis() - lastMqttAttempt < 3000) return;
  lastMqttAttempt = millis();
  Serial.print("Conectando ao broker MQTT... ");
  if (mqtt.connect(MQTT_CLIENT_ID)) {
    Serial.println("conectado");
    mqtt.subscribe(COMMAND_TOPIC);
    mqtt.subscribe(COMMAND_TOPIC_COMPAT);
    publishStatus("ESP32 conectado");
  } else {
    Serial.printf("falhou, estado=%d\n", mqtt.state());
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);
  analogReadResolution(12);
  dht.setup(DHT_PIN, DHTesp::DHT22);
  mqtt.setServer(MQTT_HOST, MQTT_PORT);
  mqtt.setCallback(onMessage);
  ensureWiFi();
}

void loop() {
  ensureWiFi();
  if (WiFi.status() == WL_CONNECTED && !clockConfigured) {
    Serial.print("WiFi conectado. IP virtual: ");
    Serial.println(WiFi.localIP());
    configTime(0, 0, "pool.ntp.org", "time.google.com");
    clockConfigured = true;
  }
  ensureMqtt();
  if (mqtt.connected()) mqtt.loop();

  if (millis() - lastPublish < PUBLISH_INTERVAL_MS) return;
  lastPublish = millis();

  TempAndHumidity reading = dht.getTempAndHumidity();
  if (isnan(reading.temperature) || isnan(reading.humidity)) {
    Serial.println("Falha na leitura do DHT22");
    return;
  }

  float lux = readLux();
  Serial.printf("Sensores: %.1f C, %.1f %%, %.1f lux\n",
                reading.temperature, reading.humidity, lux);
  if (!mqtt.connected()) {
    Serial.println("Leitura local pronta; aguardando conexao MQTT");
    return;
  }
  String timestamp = utcTimestamp();
  if (timestamp.isEmpty()) {
    Serial.println("Aguardando sincronizacao NTP para publicar com timestamp");
    return;
  }

  String payload = "t|" + String(reading.temperature, 1)
                 + "|h|" + String(reading.humidity, 1)
                 + "|l|" + String(lux, 1)
                 + "|ts|" + timestamp;
  if (mqtt.publish(TELEMETRY_TOPIC, payload.c_str())) {
    Serial.println("Publicado em " + String(TELEMETRY_TOPIC) + ": " + payload);
  } else {
    Serial.println("Falha na publicacao MQTT");
  }
}
