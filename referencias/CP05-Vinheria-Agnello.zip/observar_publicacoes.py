"""Observa mensagens MQTT do grupo durante um teste do MyMQTT.

Uso: python observar_publicacoes.py 3.135.234.101
Encerra apos 90 s; mostra somente topicos ou comandos relacionados ao grupo.
"""

import socket
import sys
import time
import uuid

from diagnostico_mqtt import field, packet, read_packet


def main(host):
    client_id = "cp05-observador-" + uuid.uuid4().hex[:10]
    with socket.create_connection((host, 1883), timeout=8) as sock:
        sock.settimeout(2)
        connect = field("MQTT") + bytes([4, 2, 0, 30]) + field(client_id)
        sock.sendall(packet(0x10, connect))
        kind, body = read_packet(sock)
        if kind != 0x20 or body != b"\x00\x00":
            raise RuntimeError(f"CONNACK inesperado: {kind:#x} {body.hex()}")

        # Apenas os namespaces do grupo, inclusive um possivel sufixo digitado errado.
        subscriptions = (
            field("vinheria571746/#") + b"\x00"
            + field("/ul/cp05vinheria571746/#") + b"\x00"
        )
        sock.sendall(packet(0x82, b"\x00\x01" + subscriptions))
        kind, body = read_packet(sock)
        if kind != 0x90 or body[:2] != b"\x00\x01" or body[2:] != b"\x00\x00":
            raise RuntimeError(f"SUBACK inesperado: {kind:#x} {body.hex()}")

        print("Observando topicos do grupo por 90 segundos...", flush=True)
        deadline = time.monotonic() + 90
        last_ping = time.monotonic()
        while time.monotonic() < deadline:
            if time.monotonic() - last_ping > 10:
                sock.sendall(b"\xc0\x00")
                last_ping = time.monotonic()
            try:
                kind, body = read_packet(sock)
            except socket.timeout:
                continue
            if kind >> 4 != 3:
                continue
            topic_length = int.from_bytes(body[:2], "big")
            topic = body[2 : 2 + topic_length].decode(errors="replace")
            message = body[2 + topic_length :].decode(errors="replace")
            if "571746" in topic or topic.endswith("/esp32_571746/"):
                print(f"TOPICO={topic!r} MENSAGEM={message!r}", flush=True)
        sock.sendall(b"\xe0\x00")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Uso: python observar_publicacoes.py IP_DO_PROFESSOR")
    main(sys.argv[1])
