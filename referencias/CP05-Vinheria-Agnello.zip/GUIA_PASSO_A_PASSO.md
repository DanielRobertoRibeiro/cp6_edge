# CP05 Vinheria: o que foi feito e como conferir

## Execução rápida a partir da entrega

**Condição necessária:** este projeto usa o broker MQTT e o FIWARE já configurados no servidor do professor `3.135.234.101`. O ZIP contém o circuito, o código e a documentação, mas não contém uma VM nem uma instalação Docker do servidor. Portanto, ele pode ser reproduzido com o servidor da turma disponível; para executá-lo em servidor próprio é preciso instalar e configurar essa infraestrutura à parte.

1. Abra o [projeto público no Wokwi](https://wokwi.com/projects/478521884866785281) e clique em **Start the simulation**. É necessário entrar na conta apenas para editar ou salvar uma cópia.
2. Deixe **uma única simulação** deste projeto rodando. Duas cópias simultâneas com o mesmo `MQTT_CLIENT_ID` podem derrubar a conexão uma da outra.
3. No Serial Monitor, confirme `WiFi conectado`, `Conectando ao broker MQTT... conectado` e `Publicado em /ul/cp05vinheria571746/esp32_571746/attrs`. A publicação ocorre a cada 5 segundos de **tempo simulado**; o intervalo real pode ser maior.
   Se aparecer `Aguardando sincronizacao NTP para publicar com timestamp`, espere o relógio sincronizar. O firmware não envia leituras sem `ts`.
4. Altere temperatura/umidade no DHT22 e luminosidade no LDR. Veja os valores mudarem no Serial Monitor.
5. No MyMQTT, conecte a `3.135.234.101:1883`, MQTT V3, SSL desligado e sem usuário/senha. Use um Client ID diferente do ESP32. Assine `/ul/cp05vinheria571746/esp32_571746/attrs` e `vinheria571746/esp32_571746/retorno`.
6. Publique a mensagem `ON` em `vinheria571746/esp32_571746/comando`; confira `LED=ON` no retorno e no Wokwi. Publique `OFF` e confira `LED=OFF`. Esta versão também aceita `vinheria571746/esp32_571746/comando:` caso o app tenha salvo o `:` final.
7. Para consultar a entidade e o histórico no servidor, siga os comandos da seção 4. Eles exigem os cabeçalhos `Fiware-Service` e `Fiware-ServicePath`.

**Recriação a partir do ZIP:** extraia `CP05-Vinheria-Agnello.zip` em uma pasta. No [novo projeto ESP32 do Wokwi](https://wokwi.com/projects/new/esp32), substitua `sketch.ino` e `diagram.json` pelos arquivos extraídos e crie `libraries.txt` com o conteúdo incluído no ZIP. Inicie a simulação. Para executar os scripts de diagnóstico no PowerShell, entre primeiro na pasta extraída com `Set-Location 'CAMINHO_DA_PASTA_EXTRAIDA'`; depois execute os comandos deste guia. Python é necessário apenas para os scripts de diagnóstico, não para o Wokwi ou MyMQTT.

## 1. Onde está o projeto

No computador do grupo, os arquivos de execução estão em `C:\Users\danie\Documents\Codex\2026-10-21\po\outputs\cp05-vinheria`. Em outro computador, use a pasta onde o ZIP foi extraído.

- `sketch.ino`: programa que roda no ESP32 simulado.
- `diagram.json`: ESP32, DHT22, LDR, LED e conexões.
- `libraries.txt`: bibliotecas exigidas pelo programa.
- `provisionar-fiware.ps1`: verifica/cadastra os recursos do grupo no FIWARE.
- `diagnostico_mqtt.py`: teste isolado do broker MQTT.
- `teste_comando_mqtt.py`: teste de comando e resposta com o ESP32.
- `observar_publicacoes.py`: mostra o tópico e a mensagem realmente enviados pelo MyMQTT.
- `README.md`: documento principal para entrega.
- `ROTEIRO_VIDEO.md`: ordem sugerida da gravação.
- `wokwi-salvo-comandos.png`: captura da versão salva com o Serial Monitor mostrando as respostas.
- `wokwi-mymqtt-on.png` e `wokwi-mymqtt-off.png`: capturas do LED durante comandos do celular.

A primeira cópia pública do Wokwi usada nos testes foi excluída. Depois de uma queda de estado da aba temporária, a equipe autorizou salvar uma [nova cópia pública e estável](https://wokwi.com/projects/478521884866785281). A pasta local e o ZIP continuam sendo o backup completo e editável. A URL antiga pode permanecer em cache por algum tempo, mas foi removida da lista de projetos da conta.

## 2. Como as peças se conectam

```text
DHT22 (temperatura/umidade) ─┐
                            ├─> ESP32 no Wokwi ─Wi-Fi─> Mosquitto MQTT :1883
LDR (luminosidade) ──────────┘                    ├─> MyMQTT recebe/publica
                                                 └─> IoT Agent :4041 ─> Orion :1026 ─> STH-Comet :8666
```

O broker transporta mensagens. O IoT Agent traduz `t`, `h`, `l` e `ts` do formato UltraLight para os atributos NGSIv2 `temperature`, `relativeHumidity`, `illuminance` e `dateObserved`. O Orion guarda o estado atual. O STH-Comet guarda o histórico. A entidade é do tipo `Device` e tem `controlledProperty`, como exige o Smart Data Model Device.

## 3. O que o servidor do professor permite acessar

O IP `3.135.234.101` identifica a máquina pública. O acesso abaixo é às **APIs do FIWARE e ao broker**. O IP sozinho não dá acesso ao console da AWS, ao Linux nem aos contêineres. Para isso seriam necessárias credenciais administrativas ou uma chave SSH, que não foram fornecidas ao grupo. O script `provisionar-fiware.ps1` apenas cadastra recursos em uma instalação FIWARE que já esteja funcionando; não instala o servidor.

1. Abra `http://3.135.234.101:1026/version`. O JSON com `orion.version` comprova que o Orion responde. No teste, respondeu `3.11.0`.
2. Abra `http://3.135.234.101:4041/iot/about`. O JSON com `version` comprova que o IoT Agent responde. No teste, respondeu `3.7.0`.
3. No PowerShell, teste a porta MQTT:

   ```powershell
   Test-NetConnection 3.135.234.101 -Port 1883
   ```

   Procure `TcpTestSucceeded : True`. Isso verifica apenas a conexão TCP; não prova recebimento MQTT.
4. Para testar MQTT completo, execute:

   ```powershell
   python .\diagnostico_mqtt.py 3.135.234.101
   ```

   Procure `CONNECT`, `SUBSCRIBE`, `PUBLISH` e `RECEIVE`. Em 21/10 os quatro passos passaram.

## 4. Como ver os dados do grupo no FIWARE

As APIs de dados precisam dos dois cabeçalhos que separam o serviço do grupo. No PowerShell:

```powershell
$server = '3.135.234.101'
$headers = @{ 'Fiware-Service'='vinheria571746'; 'Fiware-ServicePath'='/' }
Invoke-RestMethod -Uri "http://${server}:1026/v2/entities/urn%3Angsi-ld%3ADevice%3Avinheria-571746" -Headers $headers | ConvertTo-Json -Depth 8
```

Observe `temperature`, `relativeHumidity`, `illuminance`, `dateObserved`, `controlledProperty` e `deviceCategory`. `TimeInstant` é o horário em que o Orion recebeu a alteração; `dateObserved` veio do relógio do ESP32. Se esses horários pararem de avançar, não há telemetria nova.

Para confirmar o cadastro no IoT Agent:

```powershell
Invoke-RestMethod -Uri "http://${server}:4041/iot/devices/esp32_571746" -Headers $headers | ConvertTo-Json -Depth 8
```

Procure `transport: MQTT` e o mapa `t` → `temperature`, `h` → `relativeHumidity`, `l` → `illuminance`, `ts` → `dateObserved`.

Para as últimas temperaturas históricas:

```powershell
Invoke-RestMethod -Uri "http://${server}:8666/STH/v2/entities/urn%3Angsi-ld%3ADevice%3Avinheria-571746/attrs/temperature?type=Device&lastN=3" -Headers $headers | ConvertTo-Json -Depth 8
```

O array `value` contém amostras com `recvTime` e `attrValue`. Esse teste retornou amostras em 21/10.

## 5. Como recriar e testar o Wokwi

1. Abra a [versão salva do CP05](https://wokwi.com/projects/478521884866785281). Para reconstruir do zero, crie um novo projeto ESP32 em `https://wokwi.com/projects/new/esp32`.
2. Se estiver reconstruindo, cole o conteúdo dos três arquivos locais nos arquivos de mesmo nome do Wokwi. Se `libraries.txt` não existir, crie-o.
3. Inicie a simulação. No Serial Monitor, espere `WiFi conectado`, `Conectando ao broker MQTT... conectado` e `Publicado em /ul/.../attrs`.
4. Clique no DHT22 e altere temperatura e umidade. Clique no LDR e altere a luminosidade. As leituras devem mudar no Serial Monitor e no MyMQTT.
5. Se aparecer `WiFi Error: Connection to IoT Gateway wss://netwi.wokwi.com/ failed`, o problema está no acesso do simulador à rede virtual. Na sessão de 21/10 o circuito leu `13.0 C`, `70.0 %` e `100.0 lux`, mas não conseguiu publicar durante o erro. Após recriar o projeto temporário, o gateway recuperou, o Serial Monitor mostrou `WiFi conectado` e a publicação voltou.

O projeto atual foi salvo publicamente a pedido da equipe. O código contém o IP do professor; não acrescente senhas nem dados particulares a essa cópia.

**Atenção à aba temporária:** recarregar, fechar ou perder o estado de `projects/new/esp32` pode devolver o Wokwi ao ESP32 vazio. Nesse caso, o celular continuará conectado ao broker, mas `ON` não terá nenhum ESP32 ativo para recebê-lo. Prefira o link público salvo acima ou recarregue os três arquivos locais, inicie a simulação e espere `MQTT... conectado` antes de repetir o comando.

## 6. Como testar o MyMQTT

1. Configure broker `3.135.234.101`, porta `1883`, MQTT V3, SSL desligado, sem usuário e sem senha. Use um Client ID próprio do celular.
2. Confirme `Connected` na tela principal. A lista de tópicos `Enabled` pode continuar visível mesmo quando a conexão cair; por isso observe o status da conexão.
3. Assine `/ul/cp05vinheria571746/esp32_571746/attrs` para as leituras e `vinheria571746/esp32_571746/retorno` para as respostas.
4. Quando o Wokwi estiver publicando, veja mensagens como `t|13.0|h|70.0|l|100.0|ts|...` no tópico de leituras.
5. Publique `ON`, `OFF` e `STATUS` no tópico `vinheria571746/esp32_571746/comando`. Veja a resposta em `retorno` e o LED no Wokwi.

Para testar apenas o celular e o broker, assine `vinheria571746/diagnostico/telefone` e, no computador, execute:

```powershell
python .\diagnostico_mqtt.py 3.135.234.101 vinheria571746/diagnostico/telefone CP05_TESTE
```

Esse teste passou em 21/10: o MyMQTT recebeu `CP05_TESTE_CELULAR_21OUT`. Isso confirma que o erro anterior `You are not connected` foi uma desconexão do app naquele momento; não indica falha permanente do servidor.

Se a tela do app mostrar apenas o `ON` enviado, confira se o tópico de retorno está inscrito e Enabled. O aplicativo precisa de uma inscrição separada para ler a resposta. Para isolar o ESP32 do celular, execute `python .\teste_comando_mqtt.py 3.135.234.101 STATUS`; o teste deve devolver `ESP32 ativo | LED=...`. `ON` e `OFF` também são aceitos. Na versão salva do Wokwi, os três comandos foram recebidos e respondidos corretamente pelo ESP32.

No teste de 21/10, uma captura do MyMQTT mostrou `vinheria571746/esp32_571746/` como Enabled. Esse tópico termina antes de `retorno` e não corresponde ao tópico usado pelo ESP32. Complete o nome até `vinheria571746/esp32_571746/retorno` e toque em **Subscribe**. Uma linha parecida com `vinheris571746/...` também é diferente: confira cada letra e número.

Outra captura da tela **Publish** mostrou `You are not connected`, tópico `vinheria571746/esp32_571746/` e mensagem `a`. Nessa situação o comando não é transmitido. Reconecte no Dashboard, confirme o indicador verde `Connected`, e só então publique **Topic** `vinheria571746/esp32_571746/comando` com **Message** `ON`. Mantenha o MyMQTT em primeiro plano durante o envio; o Wokwi pode ficar aberto no computador.

Um observador MQTT no computador confirmou outra tentativa do celular: o broker recebeu tópico `vinheria571746/esp32_571746/comando:` e texto `Message On`. O `:` final cria outro tópico e `Message On` não é o comando `ON`. Limpe os dois campos do Publish e preencha apenas o valor, sem copiar os rótulos `Topic:` e `Message:`:

```text
Campo Topic   → vinheria571746/esp32_571746/comando
Campo Message → ON
```

Em uma nova tentativa, a mensagem já estava correta (`ON`), mas o tópico ainda terminou em `comando:`. O código do ESP32 foi testado com `STATUS`, `ON` e `OFF` enviados pelo computador e respondeu corretamente. Para completar a demonstração, atualizamos o firmware para assinar também `vinheria571746/esp32_571746/comando:`. A partir daí, o MyMQTT publicou `ON` e `OFF` no tópico com `:`; o broker, o Wokwi e o app confirmaram `LED=ON` e `LED=OFF`. Para novos clientes, prefira o tópico principal sem `:`. O valor da mensagem deve ser apenas `ON`, `OFF` ou `STATUS`.

## 7. O papel dos Tinkercads antigos

- `CP2 EDGE VINHARIA AGNELLO`: Arduino Uno, LDR e sensores analógicos, LCD, buzzer e LEDs. Mostra a ideia de monitorar a adega, mas não usa ESP32, DHT22, Wi-Fi ou MQTT.
- `Copy of Cp 4`: Arduino Uno, entradas A0/A1/A2 e LEDs. Também não usa ESP32, DHT22, Wi-Fi ou MQTT. O enunciado oficial do CP04 trata da instalação e dos health checks do FIWARE em Linux; portanto, o nome da montagem não a transforma na entrega do CP04.

O CP05 especifica expressamente ESP32 + DHT22 + LDR no Wokwi e leitura/escrita pelo MyMQTT. Por isso o circuito novo implementa esses sensores e a comunicação exigida. Os LEDs/LCD/buzzer antigos são opcionais para a continuidade visual do projeto, mas não substituem os requisitos do CP05. O LED único atual demonstra a escrita MQTT; podemos ampliar a apresentação depois sem alterar o fluxo principal.

## 8. Checklist para reproduzir e avaliar

- As leituras no MyMQTT e os comandos `ON` e `OFF` enviados pelo celular foram confirmados em 21/10/2026.
- O vídeo deve mostrar sensores, Serial Monitor, MyMQTT e respostas aos comandos. A sequência sugerida está em `ROTEIRO_VIDEO.md`.
- O README identifica os três integrantes e seus RMs. O ZIP contém os arquivos necessários para executar no Wokwi com o servidor da turma.
