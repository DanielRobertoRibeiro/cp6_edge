# Roteiro de demonstração do CP05 (2 a 4 minutos)

1. **Abertura:** mostrar o nome Vinheria Agnello e os três integrantes do README.
2. **Circuito:** exibir ESP32, DHT22, LDR e LED no Wokwi; apontar as ligações principais e as bibliotecas.
3. **Leituras:** iniciar a simulação e mostrar no Serial Monitor a conexão WiFi/MQTT e uma mensagem `t|...|h|...|l|...|ts|...`.
4. **Mudança dos sensores:** alterar temperatura e umidade no DHT22 e luminosidade no LDR; mostrar as novas mensagens e valores no MyMQTT.
5. **Escrita pelo MyMQTT:** publicar `ON` no tópico de comandos; mostrar o LED aceso e a resposta `LED=ON`. Repetir com `OFF` e mostrar LED apagado.
6. **Servidor:** mostrar a consulta Orion com os quatro atributos atualizados. Não exibir senhas, códigos de autenticação ou outros dados privados.
7. **Fechamento:** mostrar rapidamente os arquivos entregues e o link da versão salva do Wokwi. O projeto público não contém senhas.

Gravem a tela do Wokwi e, para o celular, usem gravação de tela própria ou uma segunda câmera. Antes de gravar, mantenham a simulação rodando e deixem as inscrições nos tópicos já preparadas no MyMQTT.

No MyMQTT deste teste, o tópico de Publish ficou salvo com `:` no final (`vinheria571746/esp32_571746/comando:`). A versão atual do ESP32 aceita esse tópico e o nome principal sem `:`. Para a gravação, use o que já funcionou no celular, com Message exatamente `ON` e depois `OFF`; mostre o retorno em `vinheria571746/esp32_571746/retorno`.
