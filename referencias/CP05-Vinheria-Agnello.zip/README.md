# Check Point 05 — Vinheria Agnello

**Equipe:** Daniel Roberto (RM 571746), Jecky Cossio (RM 572226) e Felipe Pedrol (RM 569631).

## Objetivo

O ESP32 simulado no Wokwi mede temperatura e umidade com DHT22 e luminosidade com LDR. A cada 5 segundos ele publica as leituras por MQTT no servidor de IoT da turma. O IoT Agent UltraLight converte as mensagens em atributos de uma entidade no Orion Context Broker. O aplicativo MyMQTT pode ler as mensagens e enviar comandos ao ESP32 para controlar o LED de demonstração.

```text
DHT22 + LDR → ESP32 no Wokwi → MQTT (Mosquitto) → IoT Agent → Orion → STH-Comet
                            ↑                 ↓
                  comandos do MyMQTT    leituras no MyMQTT
```

## Arquivos

| Arquivo | Finalidade |
| --- | --- |
| `sketch.ino` | Programa do ESP32: WiFi, sensores, MQTT, timestamp e LED. |
| `diagram.json` | Circuito Wokwi com ESP32, DHT22, LDR, LED e resistor. |
| `libraries.txt` | Bibliotecas PubSubClient e DHT sensor library for ESPx. |
| `provisionar-fiware.ps1` | Recria o cadastro no IoT Agent e a assinatura histórica, se faltarem. |
| `diagnostico_mqtt.py` | Testa conexão, inscrição, publicação e recebimento no broker sem bibliotecas extras. |
| `teste_comando_mqtt.py` | Envia `ON`, `OFF` ou `STATUS` e espera a resposta real do ESP32. |
| `observar_publicacoes.py` | Mostra por 90 segundos as publicações MQTT nos tópicos do grupo para diagnosticar erros de digitação no celular. |
| `GUIA_PASSO_A_PASSO.md` | Explica os testes, os componentes do servidor e o diagnóstico do MyMQTT/Wokwi. |
| `ROTEIRO_VIDEO.md` | Sequência sugerida para gravar a demonstração. |
| `wokwi-demonstracao.png` | Captura local do circuito e das publicações no Serial Monitor. |
| `wokwi-salvo-comandos.png` | Captura do projeto público salvo após os testes de comando e resposta. |
| `wokwi-led-on.png` | Evidência visual do LED aceso após receber `ON` por MQTT. |
| `wokwi-mymqtt-on.png` e `wokwi-mymqtt-off.png` | Capturas do LED e do Serial Monitor durante os comandos enviados pelo celular. |

## Pré-requisitos e execução

1. Abra o [projeto CP05 no Wokwi](https://wokwi.com/projects/478521884866785281). Clique em **Start the simulation**; entre em sua conta apenas se quiser editar ou salvar uma cópia. O projeto foi salvo publicamente a pedido da equipe.
2. Para recriar ou modificar uma cópia, crie um [novo projeto ESP32](https://wokwi.com/projects/new/esp32). Substitua o conteúdo de `sketch.ino` e `diagram.json` pelos arquivos deste diretório. Pelo **Library Manager**, adicione as duas bibliotecas de `libraries.txt` (ou crie esse arquivo com as duas linhas).
3. No início de `sketch.ino`, confira `MQTT_HOST` (endereço fornecido pelo professor). A conexão usa a rede virtual `Wokwi-GUEST` e a porta MQTT `1883`. Os arquivos locais permitem recriar o projeto caso a URL mude ou fique indisponível.
4. No Serial Monitor, aguarde `Conectando ao broker MQTT... conectado` e mensagens `Publicado em ...` a cada 5 segundos de tempo simulado. Deixe apenas uma cópia desta simulação ativa por vez, pois o Client ID do ESP32 é fixo. Se o gateway do Wokwi estiver indisponível, o programa ainda mostrará as leituras locais e tentará reconectar.
5. Clique no DHT22 e altere os controles de temperatura/umidade. Clique no LDR e altere a luminosidade. Observe que as mensagens MQTT mudam.

O Wokwi precisa de acesso à internet para chegar ao broker público. Em uma montagem física, adapte a rede WiFi, a alimentação e a calibração do LDR.

O servidor do professor cumpre o papel da VM Linux com broker e FIWARE. Para esta versão do CP, não é preciso criar outra VM no notebook. **A execução completa depende desse servidor continuar disponível.** O ZIP não instala uma VM nem os serviços FIWARE. Se a equipe optar por uma VM própria depois, ela precisará executar Mosquitto, IoT Agent, Orion e STH-Comet, configurar os mesmos cadastros e tornar o broker alcançável pelo Wokwi.

## Ligações

| Componente | Pino do componente | ESP32 |
| --- | --- | --- |
| DHT22 | VCC / GND / SDA | 3V3 / GND / GPIO 15 |
| Módulo LDR | VCC / GND / AO | 3V3 / GND / GPIO 34 (ADC1) |
| LED com resistor 220 Ω | anodo / catodo | GPIO 2 / GND |

O valor do LDR é convertido em lux com os parâmetros padrão do componente do Wokwi (`RL10=50 kΩ`, `gamma=0,7`). São valores aproximados; a conversão em hardware real depende de calibração.

## MQTT e FIWARE

O IoT Agent já foi provisionado no servidor da turma com os identificadores do grupo. O servidor não exigiu usuário/senha MQTT durante os testes. **Não use este broker para dados particulares ou sensíveis.**

O arquivo `sketch.ino` contém o endereço do servidor informado pelo professor para funcionar imediatamente. A equipe decidiu manter também uma cópia pública no Wokwi. Pessoas com o link podem ler o código e o endereço; não inclua senhas ou dados particulares nesse projeto.

Se o cadastro for removido de uma instalação FIWARE já funcional, extraia o ZIP, entre na pasta extraída com `Set-Location 'CAMINHO_DA_PASTA_EXTRAIDA'` e execute `.\provisionar-fiware.ps1 -Server '3.135.234.101'` no PowerShell. O script verifica o que já existe e cria apenas os recursos faltantes; ele não instala o servidor. Depois inicie o Wokwi e, se a entidade ainda não existir, execute o script novamente para adicionar os campos do Smart Data Model.

| Campo | Valor |
| --- | --- |
| `Fiware-Service` | `vinheria571746` |
| `Fiware-ServicePath` | `/` |
| API key do serviço UltraLight | `cp05vinheria571746` |
| Device ID | `esp32_571746` |
| Entity ID no Orion | `urn:ngsi-ld:Device:vinheria-571746` |
| Tópico das leituras | `/ul/cp05vinheria571746/esp32_571746/attrs` |
| Tópico dos comandos | `vinheria571746/esp32_571746/comando` |
| Tópico das respostas | `vinheria571746/esp32_571746/retorno` |

O firmware também aceita `vinheria571746/esp32_571746/comando:` como tópico de entrada alternativo, porque o MyMQTT do teste salvou esse `:` final. O tópico sem `:` é o nome principal para novos clientes; ambos enviam a resposta ao mesmo tópico `retorno`.

A entidade usa o [Smart Data Model `Device`](https://github.com/smart-data-models/dataModel.Device/blob/master/Device/doc/spec.md): `controlledProperty` lista `temperature`, `relativeHumidity` e `illuminance`; `deviceCategory` indica `sensor`. O IoT Agent recebe os códigos curtos `t`, `h`, `l` e `ts` e os traduz para atributos NGSIv2 no Orion.

Formato UltraLight enviado pelo ESP32:

```text
t|13.0|h|70.0|l|100.0|ts|2026-10-21T14:55:16Z
```

`t` representa temperatura em °C, `h` umidade relativa em %, `l` luminosidade aproximada em lux e `ts` data/hora UTC obtida via NTP. O ESP32 aguarda a sincronização NTP antes de publicar; assim toda leitura enviada inclui `ts`. No Orion, os atributos se chamam `temperature`, `relativeHumidity`, `illuminance` e `dateObserved`.

### Verificar a entidade no Orion

No PowerShell, defina o IP do servidor informado pelo professor e execute:

```powershell
$server = '3.135.234.101'
$headers = @{ 'Fiware-Service'='vinheria571746'; 'Fiware-ServicePath'='/' }
Invoke-RestMethod -Uri "http://${server}:1026/v2/entities/urn%3Angsi-ld%3ADevice%3Avinheria-571746" -Headers $headers | ConvertTo-Json -Depth 8
```

As leituras do ESP32 chegaram ao Orion por MQTT. Uma assinatura ativa também envia as mudanças para o STH-Comet. A consulta histórica pela API **v2** retornou amostras de temperatura, umidade e luminosidade, confirmando a persistência no servidor.

Para consultar as três últimas temperaturas históricas:

```powershell
$server = '3.135.234.101'
$headers = @{ 'Fiware-Service'='vinheria571746'; 'Fiware-ServicePath'='/' }
Invoke-RestMethod -Uri "http://${server}:8666/STH/v2/entities/urn%3Angsi-ld%3ADevice%3Avinheria-571746/attrs/temperature?type=Device&lastN=3" -Headers $headers | ConvertTo-Json -Depth 8
```

## Testar com MyMQTT

1. Instale o app MyMQTT no celular. Crie uma conexão com o **IP do professor**, porta **1883**, protocolo MQTT sem TLS. Use um Client ID diferente de `vinheria-esp32-571746`. Deixe usuário/senha vazios, como no teste do broker. Conecte.
2. Inscreva-se nos tópicos de **leituras** e **respostas** da tabela acima. Inicie a simulação e confira as mensagens chegando.
3. Publique `ON` no tópico de **comandos**. O LED deve acender e o tópico de respostas deve informar `LED=ON`.
4. Publique `OFF`. O LED deve apagar e a resposta deve mostrar `LED=OFF`. Publique `STATUS` para verificar que o ESP32 responde sem mudar o LED.

Use exatamente as letras maiúsculas ou minúsculas; o firmware normaliza o comando. O aplicativo deve estar na internet. Se a conexão falhar, teste primeiro o broker no computador e confirme com o professor se a porta 1883 continua acessível.

**Se o app conectar mas não mostrar leituras:** confirme que a porta é `1883` (não `1833`), selecione MQTT V3, cadastre o tópico de leituras exatamente com a barra inicial `/`, ative a inscrição e abra a visualização de mensagens. O teste com um segundo cliente inscrito nesse tópico recebeu uma mensagem nova do ESP32.

Para separar problemas do app e da simulação, entre na pasta extraída do ZIP e execute `python .\diagnostico_mqtt.py 3.135.234.101`. O script conecta, assina um tópico temporário, publica nele e confirma o recebimento. Para testar o telefone, assine `vinheria571746/diagnostico/telefone` no MyMQTT e execute `python .\diagnostico_mqtt.py 3.135.234.101 vinheria571746/diagnostico/telefone CP05_TESTE`. Esse tópico não alimenta o Orion. Python é necessário apenas para esses testes adicionais.

Se o app mostrar apenas o comando que você enviou, confirme a inscrição **separada** em `vinheria571746/esp32_571746/retorno` (sem barra inicial). Para testar o ESP32 pelo computador, execute `python teste_comando_mqtt.py IP_DO_PROFESSOR STATUS`; a saída deve conter `ESP32 ativo | LED=...`. O teste também aceita `ON` e `OFF`.

O tópico `vinheria571746/esp32_571746/` sem o sufixo `retorno` **não** recebe a resposta. Ao cadastrar no MyMQTT, confira que a linha Enabled contém o nome completo.

Ao publicar, confirme também o tópico **com o sufixo `comando`** e a mensagem `ON` ou `OFF`, sem texto adicional. Se aparecer `You are not connected`, volte ao Dashboard e reconecte antes de tocar em Publish; mensagens mostradas na lista local do app não comprovam que chegaram ao broker.

Na tela Publish, digite apenas o **valor** em cada campo: no Topic, preferencialmente `vinheria571746/esp32_571746/comando`; no Message, `ON`. Não inclua os rótulos `Topic:`/`Message:` nem texto como `Message On`. O firmware atualizado aceita também o tópico com `:` final que ficou salvo no app durante esta demonstração; nesse caso a Message ainda precisa ser exatamente `ON` ou `OFF`.

Se o monitor serial exibir `Leitura local pronta; aguardando conexao MQTT` e o Wokwi mostrar `WiFi Error: Connection to IoT Gateway wss://netwi.wokwi.com/ failed`, o ESP32 está lendo os sensores, mas o simulador não alcança a rede virtual. Enquanto isso, novas leituras não aparecerão no MyMQTT nem no Orion. Reinicie a simulação quando o gateway voltar a funcionar; confira primeiro `WiFi conectado` e depois `Conectando ao broker MQTT... conectado`.

## Verificações realizadas

- O broker MQTT público aceitou a conexão de teste e recebeu uma leitura UltraLight.
- O IoT Agent traduziu essa leitura e o Orion exibiu a entidade do grupo com temperatura, umidade, luminosidade e timestamp.
- Uma assinatura Orion → STH-Comet recebeu notificações com HTTP 200. A API histórica v2 retornou várias amostras de `temperature`, `relativeHumidity` e `illuminance`.
- O projeto compilou no Wokwi. Após uma falha temporária no gateway público do simulador, reconectou ao WiFi/MQTT e publicou `t|18.0|h|65.0|l|398.2|ts|2026-10-21T15:05:12Z`.
- A consulta ao Orion retornou `temperature=18`, `relativeHumidity=65`, `illuminance=398.2` e `dateObserved=2026-10-21T15:05:12Z`, confirmando o fluxo completo ESP32 → MQTT → IoT Agent → Orion.
- Um segundo cliente MQTT enviou `ON` e `OFF`; o ESP32 respondeu `LED=ON` e `LED=OFF` respectivamente.
- Em 21/10, o MyMQTT no celular permaneceu conectado, recebeu `CP05_TESTE_CELULAR_21OUT` do computador e recebeu leituras reais do tópico do ESP32.
- Após uma falha intermitente do gateway, a cópia temporária não salva do Wokwi voltou a conectar ao Wi-Fi e publicou `t|13.0|h|70.0|l|100.0|ts|2026-10-21T19:53:51Z`. O Orion voltou a mostrar temperatura 13, umidade 70 e luminosidade 100.
- Na cópia pública salva, o computador publicou `STATUS`, `ON` e `OFF` no tópico de comandos e recebeu, respectivamente, `ESP32 ativo | LED=OFF`, `Comando ON recebido | LED=ON` e `Comando OFF recebido | LED=OFF`. O Serial Monitor exibiu as mesmas três respostas.
- Depois da correção de compatibilidade, o MyMQTT publicou `ON` e `OFF` no tópico `.../comando:`. O broker, o Serial Monitor e o próprio app registraram `Comando ON recebido | LED=ON` e `Comando OFF recebido | LED=OFF`; o LED acendeu e apagou. A consulta ao Orion continuou mostrando `temperature=13`, `relativeHumidity=70`, `illuminance=100` e `dateObserved` atualizado.
- Na revisão de reprodução, o ZIP foi extraído em uma pasta temporária e os scripts `diagnostico_mqtt.py` e `teste_comando_mqtt.py STATUS` passaram a partir dessa pasta. O link público compilou novamente; após aguardar o NTP, publicou `t|13.0|h|70.0|l|100.0|ts|2026-10-21T21:02:48Z`, recebido pelo Orion.

## Entrega

Entregar estes arquivos, o [link do Wokwi](https://wokwi.com/projects/478521884866785281) e um vídeo curto mostrando circuito, alterações dos sensores, publicações MQTT, visualização no MyMQTT e envio dos comandos `ON`/`OFF`. Uma cópia pública anterior foi excluída; o link acima é a versão vigente. Confira o prazo e o formato de envio na plataforma da disciplina.
